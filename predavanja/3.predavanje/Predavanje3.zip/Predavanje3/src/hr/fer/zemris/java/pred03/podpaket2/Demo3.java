package hr.fer.zemris.java.pred03.podpaket2;

public class Demo3 {

	@FunctionalInterface
	public interface Processor {
		void process(double value, double transformedValue);
	}
	
	public static void main(String[] args) {
		double[] unos = {1,2,3,4,5,6,7,8,9,10};
		String operacija = "kvadriraj";
		
		if(!operacija.equals("dodaj3") && !operacija.equals("kvadriraj")) {
			System.out.println("Dragi korisniče, ...");
			return;
		}

		Processor p1 = new Processor() {
			
			@Override
			public void process(double value, double transformedValue) {
				System.out.printf("%f -> %f%n", value, transformedValue);
			}
			
		};

		Processor p2 = new Processor() {
			
			@Override
			public void process(double value, double transformedValue) {
				System.out.printf("%f -> %f%n", value, transformedValue);
			}
			
		};
				
		Processor p3 = (double value, double transformedValue) -> {
			System.out.printf("%f -> %f%n", value, transformedValue);
		};

//		Processor p4 = (value, transformedValue) -> {
//			System.out.printf("%f -> %f%n", value, transformedValue);
//		};
//
	}
}
