package hr.fer.zemris.java.pred03.podpaket;

public interface Transformer {
	double transform(double value);
}