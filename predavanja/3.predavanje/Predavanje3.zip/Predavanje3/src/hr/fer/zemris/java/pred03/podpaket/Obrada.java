package hr.fer.zemris.java.pred03.podpaket;

public class Obrada {

	private Transformer transformer;
	private Processor processor;
	
	public void obradi(double[] elements) {
		
	}
}
