package hr.fer.zemris.java.pred03.podpaket;

public class Add3Transformer implements Transformer {
	@Override
	public double transform(double štefica) {
		return štefica + 3;
	}
}