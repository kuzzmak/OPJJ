package hr.fer.zemris.java.pred03.podpaket;

@FunctionalInterface
public interface Processor {
	void process(double value, double transformedValue);
}