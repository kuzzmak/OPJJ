package hr.fer.zemris.java.pred03.podpaket;

public class SquareTransformer implements Transformer {
	@Override
	public double transform(double value) {
		return value*value;
	}
}