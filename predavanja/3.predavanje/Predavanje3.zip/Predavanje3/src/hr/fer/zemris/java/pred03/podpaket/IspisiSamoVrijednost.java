package hr.fer.zemris.java.pred03.podpaket;

public class IspisiSamoVrijednost implements Processor {
	@Override
	public void process(double value, double transformedValue) {
		System.out.println(transformedValue);
	}
}