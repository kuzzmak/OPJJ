package hr.fer.zemris.java.pred03.podpaket;

public class Demo2 {

	public static void main(String[] args) {
		double[] unos = {1,2,3,4,5,6,7,8,9,10};
		String operacija = "kvadriraj";
		
		if(!operacija.equals("dodaj3") && !operacija.equals("kvadriraj")) {
			System.out.println("Dragi korisniče, ...");
			return;
		}

		Transformer t = null;
		if(operacija.equals("dodaj3")) {
			t = new Add3Transformer();
		} else if(operacija.equals("kvadriraj")) {
			t = new SquareTransformer();
		}

		
		Transformer t3 = new Transformer() {
			@Override
			public double transform(double value) {
				return value-4;
			}
		};
		
		
		new Transformer() {
			@Override
			public double transform(double value) {
				return value-4;
			}
		};

		Transformer t4 = (double value) -> {
				return value-4;
			};
		
		
		
		Processor p = new IspisiSamoVrijednost();
		
		Processor p2 = new Processor() {
			
			@Override
			public void process(double value, double transformedValue) {
				System.out.printf("%f -> %f%n", value, transformedValue);
			}
			
		};
				
		Processor p3 = (double value, double transformedValue) -> {
			System.out.printf("%f -> %f%n", value, transformedValue);
		};

		Processor p4 = (value, transformedValue) -> {
			System.out.printf("%f -> %f%n", value, transformedValue);
		};

		obradiBrojeve(unos, t, p2);
	}

	public static void obradiBrojeve(double[] unos, Transformer t, Processor p) {
		double[] rezultat = new double[unos.length];
		for(int i = 0; i < rezultat.length; i++) {
			rezultat[i] = t.transform(unos[i]);
		}
		
		for(int i = 0; i < rezultat.length; i++) {
			p.process(unos[i], rezultat[i]);
		}
	}
}
