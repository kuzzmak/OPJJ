package hr.fer.zemris.java.pred03.podpaket;

public class IspisiSve implements Processor {
	@Override
	public void process(double value, double transformedValue) {
		System.out.println(value + " => " + transformedValue);
	}
}