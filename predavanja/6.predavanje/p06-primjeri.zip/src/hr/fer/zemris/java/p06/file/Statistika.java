package hr.fer.zemris.java.p06.file;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Statistika {

	private static class StatData {
		Map<String, Integer> brojPojavaEkstenzije = new HashMap<>();
		long ukupnaVelicina;
		long ukupnaVelicinaJavaDatoteka;
	}

	public static void main(String[] args) throws IOException {
		if(args.length != 1) {
			System.out.println("Očekivao sam 1 argument: putanju.");
			return;
		}
		
		File dir = new File(args[0]);
		
		if(!dir.isDirectory()) {
			System.out.println(dir+" ne postoji ili nije direktorij.");
			return;
		}
		
		StatData podatci = new StatData();
		listaj(dir, podatci);
		
		podatci.brojPojavaEkstenzije.forEach(
			(e,b)->System.out.format("%s ... %d%n", e, b)
		);
		System.out.format(
			"Ukupna veličina svih datoteka je %d.%n", 
			podatci.ukupnaVelicina
		);
		if(podatci.brojPojavaEkstenzije.containsKey("java")) {
			System.out.format(
				"Prosječna veličina svih java datoteka je %f.%n",
				podatci.ukupnaVelicinaJavaDatoteka / (double)podatci.brojPojavaEkstenzije.get("java")
			);
		} else {
			System.out.println("Java datoteke ne postoje.");
		}
	}

	private static void listaj(File dir, StatData podatci) throws IOException {
		File[] djeca = dir.listFiles();
		if(djeca != null) {
			for(File d : djeca) {
				if(d.isDirectory()) {
					listaj(d, podatci);
				} else {
					String ekstenzija = izvadiEkstenziju(d.getName());
					podatci.brojPojavaEkstenzije.merge(ekstenzija, 1, (s,n)->s+n);
					if(ekstenzija.equals("java")) {
						podatci.ukupnaVelicinaJavaDatoteka += d.length();
					}
					podatci.ukupnaVelicina += d.length();
				}
			}
		}
	}

	private static String izvadiEkstenziju(String name) {
		int pos = name.lastIndexOf('.');
		return pos<=0 ? "" : name.substring(pos+1).toLowerCase();
	}
}
