package hr.fer.zemris.java.p06.file.okvirnametoda;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class StatistikaOkvirnomMetodom {

	private static class StatData extends ObilazakPodstabla {
		Map<String, Integer> brojPojavaEkstenzije = new HashMap<>();
		long ukupnaVelicina;
		long ukupnaVelicinaJavaDatoteka;
		
		@Override
		public void ulazimUDirektorij(File d) {
		}
		
		@Override
		public void izlazimIzDirektorija(File d) {
		}
		
		@Override
		public void nasaoSamDatoteku(File f) {
			String ekstenzija = izvadiEkstenziju(f.getName());
			brojPojavaEkstenzije.merge(ekstenzija, 1, (s,n)->s+n);
			if(ekstenzija.equals("java")) {
				ukupnaVelicinaJavaDatoteka += f.length();
			}
			ukupnaVelicina += f.length();
		}
		
		private static String izvadiEkstenziju(String name) {
			int pos = name.lastIndexOf('.');
			return pos<=0 ? "" : name.substring(pos+1).toLowerCase();
		}
	}
	
	public static void main(String[] args) {
		if(args.length != 1) {
			System.out.println("Očekivao sam 1 argument: putanju.");
			return;
		}
		
		File dir = new File(args[0]);
		
		StatData podatci = new StatData();
		podatci.obidi(dir);
		
		podatci.brojPojavaEkstenzije.forEach(
			(e,b)->System.out.format("%s ... %d%n", e, b)
		);
		
		System.out.format(
			"Ukupna veličina svih datoteka je %d.%n", 
			podatci.ukupnaVelicina
		);
		
		if(podatci.brojPojavaEkstenzije.containsKey("java")) {
			System.out.format(
				"Prosječna veličina svih java datoteka je %f.%n",
				podatci.ukupnaVelicinaJavaDatoteka / (double)podatci.brojPojavaEkstenzije.get("java")
			);
		} else {
			System.out.println("Java datoteke ne postoje.");
		}
		
		
		
	}
}
