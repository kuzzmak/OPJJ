package hr.fer.zemris.java.p06.file.strategija;

import java.io.File;
import java.util.Objects;

public class ObilazakPodstabla {

	public static void obidi(File d, Obrada o) {
		Objects.requireNonNull(d);
		Objects.requireNonNull(o);
		if(!d.isDirectory()) {
			throw new RuntimeException(d+" ne postoji ili nije direktorij.");
		}
		obidiRekurzivno(d,o);
	}

	private static void obidiRekurzivno(File dir, Obrada o) {
		o.ulazimUDirektorij(dir);
		File[] djeca = dir.listFiles();
		if(djeca != null) {
			for(File d : djeca) {
				if(d.isDirectory()) {
					obidiRekurzivno(d, o);
				} else {
					o.nasaoSamDatoteku(d);
				}
			}
		}
		o.izlazimIzDirektorija(dir);
	}
}
