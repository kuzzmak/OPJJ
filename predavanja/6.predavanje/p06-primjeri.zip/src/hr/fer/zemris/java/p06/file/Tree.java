package hr.fer.zemris.java.p06.file;

import java.io.File;
import java.io.IOException;

public class Tree {

	public static void main(String[] args) throws IOException {
		if(args.length != 1) {
			System.out.println("Očekivao sam 1 argument: putanju.");
			return;
		}
		
		File dir = new File(args[0]);
		
		if(!dir.isDirectory()) {
			System.out.println(dir+" ne postoji ili nije direktorij.");
			return;
		}
		
		listaj(dir, 0);
	}

	private static void listaj(File dir, int indent) throws IOException {
		final int INDENT_SIZE = 4;
		if(indent==0) {
			System.out.printf("%s%n", dir.getCanonicalPath());
		} else {
			System.out.printf("%"+(INDENT_SIZE*indent)+"s%s%n", "", dir.getName());
		}
		File[] djeca = dir.listFiles();
		if(djeca != null) {
			for(File d : djeca) {
				if(d.isDirectory()) {
					listaj(d, indent+1);
				} else {
					System.out.printf("%"+(INDENT_SIZE*(indent+1))+"s%s%n", "", d.getName());
				}
			}
		}
	}
}
