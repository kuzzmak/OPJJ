package hr.fer.zemris.java.p06.file.okvirnametoda;

import java.io.File;
import java.util.Objects;

public abstract class ObilazakPodstabla {

	public final void obidi(File d) {
		Objects.requireNonNull(d);
		if(!d.isDirectory()) {
			throw new RuntimeException(d+" ne postoji ili nije direktorij.");
		}
		obidiRekurzivno(d);
	}

	private void obidiRekurzivno(File dir) {
		ulazimUDirektorij(dir);
		File[] djeca = dir.listFiles();
		if(djeca != null) {
			for(File d : djeca) {
				if(d.isDirectory()) {
					obidiRekurzivno(d);
				} else {
					nasaoSamDatoteku(d);
				}
			}
		}
		izlazimIzDirektorija(dir);
	}
	
	public abstract void ulazimUDirektorij(File d);
	public abstract void izlazimIzDirektorija(File d);
	public abstract void nasaoSamDatoteku(File f);

}
