package hr.fer.zemris.java.p06.file.strategija;

import java.io.File;

public interface Obrada {

	void ulazimUDirektorij(File d);
	void izlazimIzDirektorija(File d);
	void nasaoSamDatoteku(File f);
	
}
